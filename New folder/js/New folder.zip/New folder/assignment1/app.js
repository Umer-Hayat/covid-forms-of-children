angular.module('myapp',[])
.controller('mycon',function ($scope)
{
 $scope.item="ali";
});
